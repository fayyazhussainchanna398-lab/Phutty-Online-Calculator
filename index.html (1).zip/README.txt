# Putty Profit/Loss Calculator Online

## 🚀 How to Host on GitHub Pages
1. Create a free account at https://github.com
2. Create a new public repository (name it `putty-calculator`).
3. Upload the file `putty_calculator.html` from this ZIP.
4. Go to **Settings > Pages**.
5. Under **Source**, select `Deploy from branch`. Choose branch: `main` and folder: `/root`. Save.
6. After 2-5 minutes, your calculator will be live at:
   ```
   https://YOUR-USERNAME.github.io/putty-calculator/
   ```

## 📌 How to Add Ads (Google AdSense)
- Apply for an AdSense account: https://adsense.google.com
- After approval, you will get an ad code like:

```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1234567890123456"
     data-ad-slot="1234567890"
     data-ad-format="auto"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
```

- Replace the placeholder block in `putty_calculator.html` with your AdSense code.
- Example placeholder in file:
```html
<div style="margin:20px auto; text-align:center;">
  <!-- Google AdSense Code Yahan Paste Karein -->
</div>
```

Now, ads will show automatically.

---

Enjoy your **Profit/Loss Calculator** online and start earning with ads! 🎉
